package com.neatroots.instagramclone.utils

const val USER_NODE="User"
const val USER_PROFILE_FOLDER="Profile"