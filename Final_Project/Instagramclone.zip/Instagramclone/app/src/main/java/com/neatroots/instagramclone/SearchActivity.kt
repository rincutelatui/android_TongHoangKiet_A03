package com.neatroots.instagramclone

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class SearchActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
    //---------------- hàm tìm kiếm
        val edtlink = findViewById<EditText>(R.id.edtlink)
        val btnopen = findViewById<Button>(R.id.btnopen)
        val btnback = findViewById<Button>(R.id.btnback)

        btnopen.setOnClickListener {
            // Khai báo intent ẩn để gọi đến ứng dụng mở link web
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://"+edtlink.text.toString()+".com"))
            startActivity(intent)
            finish()
        }

        btnback.setOnClickListener {
            val intent = Intent(this , HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

    }
}