package com.neatroots.instagramclone.Models

import android.widget.TextView

class User {
    var image:String?=null
    var name:String?=null
    var email:String?=null
    var password:String?=null
    constructor()
    constructor(image: String?, name: String?, email: String?, password: String?) {
        this.image = image
        this.name = name
        this.email = email
        this.password = password
    }

    constructor(name: String?, email: String?, password: String?) {
        this.name = name
        this.email = email
        this.password = password
    }


    // constructor nay de luu bien email va password để dung trong layout login
    constructor(email: String?, password: String?) {
        this.email = email
        this.password = password
    }


    // tự thêm có gì sai thì xóa ( constructor name )
    constructor(name: String?) {
        this.name = name
    }




}