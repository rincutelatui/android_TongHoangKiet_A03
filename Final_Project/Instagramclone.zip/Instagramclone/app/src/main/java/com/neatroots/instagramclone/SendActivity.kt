package com.neatroots.instagramclone

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.annotation.SuppressLint


class SendActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send)

        val edtsend = findViewById<EditText>(R.id.edtphonenumber)
        val noidung = findViewById<EditText>(R.id.noidung)
        val btnSend = findViewById<Button>(R.id.btnsend)
        val btnback = findViewById<Button>(R.id.btnback)

        // lấy nội dung từ EditText
        val noidunggui = noidung.text.toString()

        // lấy sđt từ EditText
        val sdt = edtsend.text.toString()


        btnSend.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO)
            intent.data = Uri.parse("smsto:$sdt")
            intent.putExtra("sms_body:",noidunggui )
            startActivity(intent);
        }

        btnback.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}