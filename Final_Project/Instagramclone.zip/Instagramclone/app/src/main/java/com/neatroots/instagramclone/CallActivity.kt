package com.neatroots.instagramclone

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class CallActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        val edtcall = findViewById<EditText>(R.id.edtcall)
        val btncall = findViewById<Button>(R.id.btncall)
        val btnback = findViewById<Button>(R.id.btnback)


            // lấy sđt từ EditText
        val phoneNumber = edtcall.text.toString()

        btncall.setOnClickListener {
            val intent = Intent(Intent(Intent.ACTION_DIAL,Uri.parse("tel:$phoneNumber")))
            startActivity(intent);
        }

        btnback.setOnClickListener {
            val intent = Intent(this , HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
        }

}
