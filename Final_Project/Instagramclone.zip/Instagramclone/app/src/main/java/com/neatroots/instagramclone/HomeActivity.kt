package com.neatroots.instagramclone

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.core.app.ActivityCompat
import android.Manifest
import android.os.Message
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.neatroots.instagramclone.Models.User
import com.neatroots.instagramclone.databinding.ActivityHomeBinding



class HomeActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btncall = findViewById<Button>(R.id.btncallphone)
        btncall.setOnClickListener {
            val intent = Intent(this , CallActivity::class.java)
            startActivity(intent)
            finish()


        }

        val btnsend = findViewById<Button>(R.id.btnsendsms)
        btnsend.setOnClickListener {

            val intent = Intent(this , SendActivity::class.java)
            startActivity(intent)
            finish()

        }



        //------------------ ham logout ( neu nhu ko dc thi xoa tu day )
        val btndangxuat = findViewById<Button>(R.id.btndangxuat)
        btndangxuat.setOnClickListener {
            val intent = Intent(this , LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        val btnsearch = findViewById<Button>(R.id.btnsearch)
        btnsearch.setOnClickListener {
            val intent = Intent(this , SearchActivity::class.java)
            startActivity(intent)
            finish()
        }




//


    }
}